# -*- coding: utf-8 -*-
"""
Spyder Editor
made by Yuki Sumi
"""

import glob
import os
import shutil
from os import listdir
from PIL import Image, ImageTk #https://pillow.readthedocs.io/en/latest/handbook/tutorial.html

# ディレクトリが存在しない場合、ディレクトリを作成する
NORMAL_DIR_NAME = "normal-modified"
if os.path.exists(NORMAL_DIR_NAME):
    print("ディレクトリ", NORMAL_DIR_NAME, "が存在します")
else:
    print("ディレクトリ", NORMAL_DIR_NAME, "が存在しませんので作成します")    
    os.makedirs(NORMAL_DIR_NAME)

COVID19_DIR_NAME = "covid19-modified"
if os.path.exists(COVID19_DIR_NAME):
    print("ディレクトリ", COVID19_DIR_NAME, "が存在します")
else:
    print("ディレクトリ", COVID19_DIR_NAME, "が存在しませんので作成します")    
    os.makedirs(COVID19_DIR_NAME)
    
#画像ファイル名取得
list_healthy = [i for i in listdir('./normal') if not i.startswith('.')]
list_covid19 = [i for i in listdir('./covid19') if not i.startswith('.')]
for filename in list_healthy:
    print(filename)
print(list_covid19)


for filename in list_healthy:
    source_filename = os.path.join('./normal', filename)
    filename_without_extension = os.path.splitext(filename)[0] #拡張子を除く
    destination_filename = os.path.join(NORMAL_DIR_NAME, filename_without_extension + ".jpg")
    print(filename, destination_filename)
    try:
        original_image = Image.open(source_filename) #ファイル読み込み PillowのImageオブジェクト形式
    except OSError as e: #ファイル読み込み不成功
        print('Error:', e)
    else: #ファイル読み込み成功
        #画像形式を出力してみる
        print(original_image.format, original_image.size, original_image.mode)
        img = original_image.convert("L") # カラー→モノクロ変換
        img = img.resize((1024, 1024), Image.Resampling.LANCZOS)  # 画像大きさ変換
        try:
            img.save(destination_filename, quality=75)
        except OSError as e: #ファイル読み込み不成功
            print('Error:', e)
        else: #ファイル書き出し成功
            pass
    
for filename in list_covid19:
    source_filename = os.path.join('./covid19', filename)
    filename_without_extension = os.path.splitext(filename)[0] #拡張子を除く
    destination_filename = os.path.join(COVID19_DIR_NAME, filename_without_extension + ".jpg")
    print(filename, destination_filename)
    try:
        original_image = Image.open(source_filename) #ファイル読み込み PillowのImageオブジェクト形式
    except OSError as e: #ファイル読み込み不成功
        print('Error:', e)
    else: #ファイル読み込み成功
        #画像形式を出力してみる
        print(original_image.format, original_image.size, original_image.mode)
        img = original_image.convert("L") # カラー→モノクロ変換
        img = img.resize((1024, 1024), Image.Resampling.LANCZOS)  # 画像大きさ変換
        try:
            img.save(destination_filename, quality=75)
        except OSError as e: #ファイル読み込み不成功
            print('Error:', e)
        else: #ファイル書き出し成功
            pass
